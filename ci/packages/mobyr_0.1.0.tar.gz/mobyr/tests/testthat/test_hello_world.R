context("hello")

test_that("hello world", {
  # when
  res <- hello()
  # then
  expected_res <- "Hello"
  expect_equal(res, expected_res)
})
