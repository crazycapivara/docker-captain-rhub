library(testthat)
library(mobyr)

test_check("mobyr")
